package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tdas.ArbolAVL;
import uy.edu.ucu.aed.tdas.ILista;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.modelo.ClavePelicula;
import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.tdas.Lista;

/**
 * Clase que representa un catálogo de películas utilizando un árbol AVL.
 * Permite insertar películas y realizar búsquedas por puntaje y género.
 */
public class CatalogoPeliculasAVL implements CatalogoPeliculas {
    /**
     * Árbol AVL que almacena las películas, ordenadas por puntaje y título.
     */
    private ArbolPeliculasAVL arbolPorPuntaje;

    /**
     * Constructor de la clase CatalogoPeliculasAVL.
     * Inicializa el árbol AVL para almacenar las películas.
     */
    public CatalogoPeliculasAVL() {
        this.arbolPorPuntaje = new ArbolPeliculasAVL();
    }

    @Override
    public void insertarPelicula(Pelicula pelicula) {
        ClavePelicula clave = new ClavePelicula(pelicula.getPuntaje(), pelicula.getTitulo());
        arbolPorPuntaje.insertar(clave, pelicula);
    }

    @Override
    public ILista<Pelicula> buscarPorPuntaje(Float minimo, Float maximo) {

        Lista listaPuntaje = new Lista(); //Lista donde se iran guardando las peliculas dentro del rango deseado para luego mostrar
        /*
        Si el puntaje esta entre el minimo y el maximo, sera agregado a la lista
        El metodo devuelve la lista de puntajes
         */
        return listaPuntaje;
    }

    @Override
    public ILista<Pelicula> buscarPorGenero(String genero) {
        Lista listaRomance = new Lista();  //Creacion de la lista donde se guardaran las peliculas de genero "Romance"
        if (arbolPorPuntaje.buscar("Romance") != null){
            listaRomance.insertar(arbolPorPuntaje.buscar("romance"),"Romance" );
        }

        /*
        Al recorrer el arbol e identificar las peliculas con genero "Romance" se van agregando a la listaRomance, la cual
        al finalziar el metodo devuelve la lista
         */
        return listaRomance; //Todas las etiquetas que tengan como genero "Romance" seran agregadas a la una lista donde se va a imprimir

    }
}