package uy.edu.ucu.aed;

//import jdk.internal.org.jline.utils.OSUtils;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.parcial.CatalogoPeliculasAVL;
import uy.edu.ucu.aed.tdas.ArbolAVL;
import uy.edu.ucu.aed.utils.ManejadorArchivosGenerico;

/**
 * En esta clase se debe realizar la carga de los datos en la estructura, las búsquedas solicitadas y la escritura de los resultados en el archivo de texto.
 */
public class Main 
{
    public static void main(String[] args)
    {
        ArbolAVL arbolAVL = new ArbolAVL();
        ManejadorArchivosGenerico archivo = new ManejadorArchivosGenerico();

        // Leer archivo Pelis.txt
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("C:\\Users\\alfon\\Desktop\\Parcial1-2025\\Parcial1_Alumnos\\src\\main\\java\\uy\\edu\\ucu\\aed\\Pelis.txt");

        // Crear catálogo de películas (internamente usa un árbol AVL)
        CatalogoPeliculas catalogo = new CatalogoPeliculasAVL();


        // Cargar películas al catálogo
        for (String linea : lineas) {
            arbolAVL.insertar(linea, linea);
            for (int i = 0; i < lineas.length; i++) {
                //System.out.println(lineas[i] = lineas[i].split(",")[0]);
                for (int j = 0; j < i; j++){
                    System.out.println(lineas[0].split(",")[0]);
                }
                //System.out.println(lineas[i]);
                Pelicula pelicula = new Pelicula(lineas[i]);
                catalogo.insertarPelicula(pelicula);
            }
        }


        //Prueba de leido del txt
        System.out.println(arbolAVL.preOrden());


        // Búsqueda por puntaje: [6.0, 8.0]
        catalogo.buscarPorPuntaje(6.0F,8.0F);

        // Búsqueda por puntaje: solo máximo (<= 5.0)
        catalogo.buscarPorPuntaje(1.0F,2.0F);

        // Búsqueda por puntaje: solo mínimo (>= 7.5)
        catalogo.buscarPorPuntaje(6.0F ,7.0F);

        // Búsqueda por género: "Romance"
        catalogo.buscarPorGenero("Romance");

        // Escribir resultados en archivo "src/main/java/uy/edu/ucu/aed/ResultadoBusquedas.txt"
        archivo.escribirArchivo("resultado.txt",lineas);
    }
}
