package uy.edu.ucu.aed;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.parcial.CatalogoPeliculasAVL;
import uy.edu.ucu.aed.tdas.ArbolAVL;
import uy.edu.ucu.aed.utils.ManejadorArchivosGenerico;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit test for implemented methods.
 */
public class Parcial1Test_Junit5
{
    String instanceVariable;
    CatalogoPeliculas catalogos = new CatalogoPeliculasAVL();
    ArbolAVL arbol = new ArbolAVL();

    @BeforeEach
    public void setUp() {
        // Initialize any resources or objects needed for the tests
        instanceVariable = "Value before test";
        ManejadorArchivosGenerico archivo = new ManejadorArchivosGenerico();
        ArbolAVL arbol = new ArbolAVL();
    }

    @AfterEach
    public void tearDown() {
        // Release any resources or clean up after the tests
        instanceVariable = null;
    }

    /**
     * Sample test in JUnit 5
     */
    @Test
    public void shouldAnswerWithTrueInJUnit5Test()
    {
        assertTrue(instanceVariable != null);
    }

    @Test
    public void TestManejadorArchivos(){
        assertEquals("Archivo leído satisfactoriamente", ManejadorArchivosGenerico.leerArchivo("C:\\Users\\alfon\\Desktop\\Parcial1-2025\\Parcial1_Alumnos\\src\\main\\java\\uy\\edu\\ucu\\aed\\Pelis.txt"));
    }

    @Test
    public void TestInsertarPelicula(){
        Pelicula peli = new Pelicula("AED");
        catalogos.insertarPelicula(peli);
        //assertEquals("",peli.getTitulo());
    }
    @Test
    public void TestInsertarPeliculaTitulo(){
        Pelicula peli = new Pelicula("AED");
        catalogos.insertarPelicula(peli);
        assertEquals("AED",peli.getTitulo());
    }


    @Test
    public void TestbuscarporPuntaje(){
        catalogos.buscarPorPuntaje(6.0F,8.0F);
        //
    }
    @Test
    public void TestbuscarporPuntajeMAX(){
        catalogos.buscarPorPuntaje(1.0F,2.0F);
    }
    @Test
    public void TestbuscarporPuntajeMIN(){
        catalogos.buscarPorPuntaje(6.0F ,7.0F);
    }
    @Test
    public void Testbuscarporgenero(){
        catalogos.buscarPorGenero("Romance");
        //assertEquals("AED",peli.getTitulo()); //verifica que la lista sea la misma que la lista de genero
    }
}

